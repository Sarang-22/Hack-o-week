import { Github, Linkedin, Mail, ExternalLink, Globe, Database, Smartphone, Code } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* A4 Printable Container */}
      <div className="max-w-[210mm] mx-auto bg-white p-8 print:p-12">
        {/* Header Section */}
        <header className="text-center mb-8 pb-6 border-b-2 border-blue-600">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 mx-auto mb-4 flex items-center justify-center text-white">
            <span className="text-4xl">👨‍💻</span>
          </div>
          
          <h1 className="mb-2 text-gray-900">
            <span className="text-blue-600">Sarang Mendhekar</span>
          </h1>
          
          <p className="text-base text-gray-700 mb-4 max-w-3xl mx-auto">
            Computer Science Student & Full-Stack Developer passionate about creating 
            innovative web applications and solving complex problems through code.
          </p>
          
          <div className="flex gap-6 justify-center text-gray-600">
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 hover:text-blue-600 transition-colors"
            >
              <Github className="w-4 h-4" />
              <span className="text-sm">GitHub</span>
            </a>
            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 hover:text-blue-600 transition-colors"
            >
              <Linkedin className="w-4 h-4" />
              <span className="text-sm">LinkedIn</span>
            </a>
            <a
              href="mailto:sarang.mendhekar@email.com"
              className="flex items-center gap-1 hover:text-blue-600 transition-colors"
            >
              <Mail className="w-4 h-4" />
              <span className="text-sm">sarang.mendhekar@email.com</span>
            </a>
          </div>
        </header>

        {/* Skills Section */}
        <section className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b border-gray-300">
            Skills & Technologies
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Globe className="w-5 h-5 text-blue-600" />
                <h3 className="font-semibold text-gray-900 text-sm">Frontend</h3>
              </div>
              <ul className="space-y-1 text-xs text-gray-600">
                <li>• React</li>
                <li>• TypeScript</li>
                <li>• Tailwind CSS</li>
                <li>• Next.js</li>
              </ul>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Database className="w-5 h-5 text-blue-600" />
                <h3 className="font-semibold text-gray-900 text-sm">Backend</h3>
              </div>
              <ul className="space-y-1 text-xs text-gray-600">
                <li>• Node.js</li>
                <li>• Express</li>
                <li>• PostgreSQL</li>
                <li>• MongoDB</li>
              </ul>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Smartphone className="w-5 h-5 text-blue-600" />
                <h3 className="font-semibold text-gray-900 text-sm">Mobile</h3>
              </div>
              <ul className="space-y-1 text-xs text-gray-600">
                <li>• React Native</li>
                <li>• Flutter</li>
                <li>• iOS</li>
                <li>• Android</li>
              </ul>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Code className="w-5 h-5 text-blue-600" />
                <h3 className="font-semibold text-gray-900 text-sm">Tools</h3>
              </div>
              <ul className="space-y-1 text-xs text-gray-600">
                <li>• Git</li>
                <li>• Docker</li>
                <li>• AWS</li>
                <li>• CI/CD</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Projects Section */}
        <section className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b border-gray-300">
            Featured Projects
          </h2>
          
          <div className="space-y-4">
            {/* Project 1 */}
            <div className="border border-gray-200 rounded-lg p-4">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-semibold text-gray-900">E-Commerce Platform</h3>
                <div className="flex gap-3">
                  <a
                    href="https://github.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-600 hover:text-blue-600"
                  >
                    <Github className="w-4 h-4" />
                  </a>
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-600 hover:text-blue-600"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>
              <p className="text-sm text-gray-600 mb-2">
                A full-stack e-commerce platform built with React, Node.js, and MongoDB. 
                Features include user authentication, shopping cart, and payment integration.
              </p>
              <div className="flex flex-wrap gap-1">
                <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs">React</span>
                <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs">Node.js</span>
                <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs">MongoDB</span>
                <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs">Stripe</span>
              </div>
            </div>

            {/* Project 2 */}
            <div className="border border-gray-200 rounded-lg p-4">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-semibold text-gray-900">Task Management App</h3>
                <div className="flex gap-3">
                  <a
                    href="https://github.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-600 hover:text-blue-600"
                  >
                    <Github className="w-4 h-4" />
                  </a>
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-600 hover:text-blue-600"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>
              <p className="text-sm text-gray-600 mb-2">
                A mobile-first task management application with drag-and-drop functionality, 
                real-time updates, and team collaboration features.
              </p>
              <div className="flex flex-wrap gap-1">
                <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs">React Native</span>
                <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs">Firebase</span>
                <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs">TypeScript</span>
              </div>
            </div>

            {/* Project 3 */}
            <div className="border border-gray-200 rounded-lg p-4">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-semibold text-gray-900">Analytics Dashboard</h3>
                <div className="flex gap-3">
                  <a
                    href="https://github.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-600 hover:text-blue-600"
                  >
                    <Github className="w-4 h-4" />
                  </a>
                  <a
                    href="https://example.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-600 hover:text-blue-600"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>
              <p className="text-sm text-gray-600 mb-2">
                Interactive data visualization dashboard for analyzing business metrics. 
                Built with modern charting libraries and responsive design.
              </p>
              <div className="flex flex-wrap gap-1">
                <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs">React</span>
                <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs">D3.js</span>
                <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs">Tailwind CSS</span>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-4 pb-2 border-b border-gray-300">
            Contact Information
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Mail className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-gray-900">Email</h4>
                <a
                  href="mailto:sarang.mendhekar@email.com"
                  className="text-sm text-gray-600 hover:text-blue-600"
                >
                  sarang.mendhekar@email.com
                </a>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Github className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-gray-900">GitHub</h4>
                <a
                  href="https://github.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-gray-600 hover:text-blue-600"
                >
                  github.com/sarangmendhekar
                </a>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Linkedin className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-gray-900">LinkedIn</h4>
                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-gray-600 hover:text-blue-600"
                >
                  linkedin.com/in/sarangmendhekar
                </a>
              </div>
            </div>
          </div>

          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <p className="text-sm text-gray-700">
              <span className="font-semibold">Currently Available:</span> I'm actively seeking internship 
              opportunities and freelance projects. Let's build something amazing together!
            </p>
          </div>
        </section>

        {/* Footer */}
        <footer className="pt-6 border-t border-gray-300 text-center">
          <p className="text-sm text-gray-600">
            © 2026 Sarang Mendhekar. All rights reserved.
          </p>
        </footer>
      </div>

      {/* Print Styles */}
      <style>{`
        @media print {
          body {
            print-color-adjust: exact;
            -webkit-print-color-adjust: exact;
          }
          
          @page {
            size: A4;
            margin: 10mm;
          }
          
          .print\\:p-12 {
            padding: 1rem !important;
          }
        }
      `}</style>
    </div>
  );
}
